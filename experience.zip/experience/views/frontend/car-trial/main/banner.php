<div class="tests__item tests__item-banner" style="display:none">
    <div class="tests__item-banner-in">
        <div class="tests__item-banner-title">
            Как мы проводим испытания?
        </div>
        <div class="tests__item-banner-numbers">
            <div class="tests__item-banner-number">
                <div class="tests__item-banner-number-big">
                    12
                </div>
                <div class="tests__item-banner-number-small">
                    Марок
                </div>
            </div>
            <div class="tests__item-banner-number">
                <div class="tests__item-banner-number-big">
                    87
                </div>
                <div class="tests__item-banner-number-small">
                    испытаний
                </div>
            </div>
        </div>
        <a href="#" class="tests__item-banner-btn">
            Узнать больше
        </a>
    </div>
</div>
