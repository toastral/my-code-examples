<?php

/* @var $this yii\web\View */
/* @var $form yii\widgets\ActiveForm */
/* @var $model app\modules\experience\models\CarBrand */
?>

    <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>

